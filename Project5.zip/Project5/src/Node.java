public class Node {

    private Point start;
    private Point end;
    private Point curr;
    private Point parent;
    private double g;
    private double h;
    private double f;

    public Node(Point start, Point end, Point curr, Point parent) {
        this.start = start;
        this.end = end;
        this.curr = curr;
        this.parent = parent;
        this.g = Math.sqrt(Point.distanceSquared(curr, start));
        this.h = Math.sqrt(Point.distanceSquared(curr, end));
        this.f = g + h;
    }

    public Point getCurr() {
        return curr;
    }

    public Point getParent() {
        return parent;
    }

    public double getGCost() {
        return g;
    }

    public double getHCost() {
        return h;
    }

    public double getFCost() {
        return f;
    }

}
