import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import processing.core.PImage;

public class Atlantis extends AnimationEntity {

    public Atlantis(String id, Point position,
                 List<PImage> images, int actionPeriod, int animationPeriod) {
        super(id, position, images, actionPeriod, animationPeriod);
    }

    public static Entity createAtlantis(String id, Point position,
                                        List<PImage> images) {
        return new Atlantis(id, position, images, 0, 0);
    }

    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
                        scheduler.scheduleEvent(this,
                        createAnimationAction(this, WorldModel.ATLANTIS_ANIMATION_REPEAT_COUNT),
                        this.getAnimationPeriod());
    }

}
