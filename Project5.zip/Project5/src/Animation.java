public class Animation extends Action {


    public Animation(Entity entity, WorldModel world,
                     ImageStore imageStore, int repeatCount)
    {
        super(entity, world, imageStore, repeatCount);
    }

    public void executeAction(EventScheduler scheduler){
        ((AnimationEntity)this.entity).nextImage();

        if (this.repeatCount != 1)
        {
            scheduler.scheduleEvent(this.entity,
                    ((AnimationEntity)this.entity).createAnimationAction(entity, Math.max(this.repeatCount - 1, 0)),
                    ((AnimationEntity)this.entity).getAnimationPeriod());
        }
    }

}
