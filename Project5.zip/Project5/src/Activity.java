public class Activity extends Action {

    public Activity(Entity entity, WorldModel world,
                    ImageStore imageStore, int repeatCount)
    {
        super(entity, world, imageStore, repeatCount);
    }

    public void executeAction(EventScheduler scheduler){

        if (this.entity instanceof Octo_Full) {
            ((Octo_Full) this.entity).executeActivity(this.world, this.imageStore, scheduler);
        }

        if (this.entity instanceof Octo_Not_Full) {
            ((Octo_Not_Full) this.entity).executeActivity(this.world, this.imageStore, scheduler);
        }

        if (this.entity instanceof Fish) {
            ((Fish) this.entity).executeActivity(this.world, this.imageStore, scheduler);
        }

        if (this.entity instanceof Crab) {
            ((Crab) this.entity).executeActivity(this.world, this.imageStore, scheduler);
        }

        if (this.entity instanceof Quake) {
            ((Quake) this.entity).executeActivity(this.world, this.imageStore, scheduler);
        }

        if (this.entity instanceof Sgrass) {
            ((Sgrass) this.entity).executeActivity(this.world, this.imageStore, scheduler);
        }

        if (this.entity instanceof Atlantis) {
            ((Atlantis) this.entity).executeActivity(this.world, this.imageStore, scheduler);
        }

        if (this.entity instanceof Tornado) {
            ((Tornado) this.entity).executeActivity(this.world, this.imageStore, scheduler);
        }

        if (this.entity instanceof Piranha) {
            ((Piranha) this.entity).executeActivity(this.world, this.imageStore, scheduler);
        }

        if (this.entity instanceof Shark) {
            ((Shark) this.entity).executeActivity(this.world, this.imageStore, scheduler);
        }

        if (this.entity instanceof Godzilla) {
            ((Godzilla) this.entity).executeActivity(this.world, this.imageStore, scheduler);
        }

//        switch (this.entity.getKind())
//      {
//         case OCTO_FULL:
//            this.entity.executeOctoFullActivity(this.world,
//                    this.imageStore, scheduler);
//            break;
//
//         case OCTO_NOT_FULL:
//            this.entity.executeOctoNotFullActivity(this.world, this.imageStore, scheduler);
//            break;
//
//         case FISH:
//            this.entity.executeFishActivity(this.world, this.imageStore, scheduler);
//            break;
//
//         case CRAB:
//            this.entity.executeCrabActivity(this.world, this.imageStore, scheduler);
//            break;
//
//         case QUAKE:
//            this.entity.executeQuakeActivity(this.world, this.imageStore, scheduler);
//            break;
//
//         case SGRASS:
//            this.entity.executeSgrassActivity(this.world, this.imageStore, scheduler);
//            break;
//
//         case ATLANTIS:
//            this.entity.executeAtlantisActivity(this.world, this.imageStore, scheduler);
//            break;
//
//         default:
//            throw new UnsupportedOperationException(
//                    String.format("executeActivityAction not supported for %s",
//                            this.entity.getKind()));
//      }
    }



}
