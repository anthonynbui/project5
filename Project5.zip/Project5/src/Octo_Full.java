import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import processing.core.PImage;

public class Octo_Full extends Octo {

    private SingleStepPathingStrategy pathing;

    public Octo_Full(String id, Point position, List<PImage> images, int actionPeriod, int animationPeriod,
                         int resourceLimit, int resourceCount) {
        super(id, position, images, actionPeriod, animationPeriod, resourceLimit, resourceCount);
    }

    public static Octo_Full createOctoFull(String id, int resourceLimit,
                                           Point position, int actionPeriod, int animationPeriod,
                                           List<PImage> images) {
        return new Octo_Full(id, position, images,
                actionPeriod, animationPeriod, resourceLimit, resourceLimit);
    }

    public void executeActivity(WorldModel world,
                                ImageStore imageStore, EventScheduler scheduler) {
        Optional<Entity> fullTarget = world.findNearest(this.position,
                Atlantis.class);

        if (fullTarget.isPresent() &&
                this.moveTo(world, fullTarget.get(), scheduler)) {
            //at atlantis trigger animation
            ((Atlantis) fullTarget.get()).scheduleActions(scheduler, world, imageStore);

            //transform to unfull
            this.transformFull(world, scheduler, imageStore);
        } else {
            scheduler.scheduleEvent(this,
                    createActivityAction(this, world, imageStore),
                    this.getActionPeriod());
        }
    }


    public void transformFull(WorldModel world, EventScheduler scheduler, ImageStore imageStore) {
        Octo_Not_Full octo = Octo_Not_Full.createOctoNotFull(this.id, this.getResourceLimit(),
                this.position, this.getActionPeriod(), this.getAnimationPeriod(),
                this.images);

        world.removeEntity(this);
        scheduler.unscheduleAllEvents(this);

        world.addEntity(octo);
        octo.scheduleActions(scheduler, world, imageStore);
    }

    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler) {
        if (this.position.adjacent(target.getPosition())) {
            return true;
        } else {
            Point nextPos = this.nextPosition(world, target.getPosition());

            if (!this.position.equals(nextPos)) {
                Optional<Entity> occupant = world.getOccupant(nextPos);
                if (occupant.isPresent()) {
                    scheduler.unscheduleAllEvents(occupant.get());
                }

                world.moveEntity(this, nextPos);
            }
            return false;
        }
    }

}
