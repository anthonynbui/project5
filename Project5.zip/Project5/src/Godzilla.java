import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import processing.core.PImage;

public class Godzilla extends MoveableEntity {

    public Godzilla(String id, Point position,
                 List<PImage> images, int actionPeriod, int animationPeriod) {
        super(id, position, images, actionPeriod, animationPeriod);
    }

    public static Godzilla createGodzilla(String id, Point position,
                                    int actionPeriod, int animationPeriod, List<PImage> images) {
        return new Godzilla(id, position, images, actionPeriod, animationPeriod);
    }

    public boolean moveTo(WorldModel world,
                          Entity target, EventScheduler scheduler) {
        if (this.position.adjacent(target.getPosition())) {
            world.removeEntity(target);
            scheduler.unscheduleAllEvents(target);
            return true;
        } else {
            Point nextPos = nextPosition(world, target.getPosition());

            if (!this.position.equals(nextPos)) {
                Optional<Entity> occupant = world.getOccupant(nextPos);
                if (occupant.isPresent()) {
                    scheduler.unscheduleAllEvents(occupant.get());
                }

                world.moveEntity(this, nextPos);
            }
            return false;
        }
    }

    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        Optional<Entity> target = world.findNearest(this.position, Atlantis.class);
        long nextPeriod = getActionPeriod();

        if (target.isPresent()) {
            Point tgtPos = target.get().getPosition();

            if (this.moveTo(world, target.get(), scheduler)) {
                Quake quake = Quake.createQuake(tgtPos,
                        imageStore.getImageList(Quake.QUAKE_KEY));

                world.addEntity(quake);
                nextPeriod += this.getActionPeriod();
                quake.scheduleActions(scheduler, world, imageStore);
            }
        }

        scheduler.scheduleEvent(this,
                createActivityAction(this, world, imageStore),
                nextPeriod);
    }
}

