import java.util.List;
import java.util.*;
import java.util.PriorityQueue;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.HashMap;
import java.util.Comparator;

class AStarPathingStrategy
        implements PathingStrategy {


    public List<Point> computePath(Point start, Point end,
                                   Predicate<Point> canPassThrough,
                                   BiPredicate<Point, Point> withinReach,
                                   Function<Point, Stream<Point>> potentialNeighbors) {
        List<Point> path = new LinkedList<>();
        HashMap<Point, Node> openMap = new HashMap<>(); // Map with key Point and value Node
        PriorityQueue<Node> openListQueue = new PriorityQueue<>(Comparator.comparing(Node::getFCost).reversed().thenComparing(Node::getGCost).thenComparing(Node::getHCost).reversed());
        // Queue to help obtain lowest F

        HashMap<Point, Point> parentMap = new HashMap<>(); // Map to store a Point with its parent

        Node currNode = new Node(start, end, start, null); // first Node is the start
        openMap.put(currNode.getCurr(), currNode);

        while (!withinReach.test(currNode.getCurr(), end)) { // While we have not reached end
            List<Point> neighbors = potentialNeighbors.apply(currNode.getCurr())
                    .filter(canPassThrough)
                    .filter(pt -> !openMap.containsKey(pt) && !parentMap.containsKey(pt)) // If neighbor is not already mapped in the open list or the parent map
                    .collect(Collectors.toList()); // List of neighbors can move to

            for (int i = 0; i < neighbors.size(); i++) {
                Node newNode = new Node(start, end, neighbors.get(i), currNode.getCurr());
                openMap.put(neighbors.get(i), newNode); // Add to open list
                openListQueue.add(newNode); // Add to queue to sort new lowest F
            }

            parentMap.put(currNode.getCurr(), currNode.getParent()); // Map the chosen node with its parent
            openMap.remove(currNode.getCurr()); // Remove this current from open list
            currNode = openListQueue.peek(); // Current node is now the next new node with lowest F
            try {
                openListQueue.remove();
            } catch (Exception e) { // In case there is nothing left in the queue
                return path;
            }
        }

        path.add(0, currNode.getCurr()); // Adds last point before the end
        Point parent = currNode.getParent();

        while (parent != start) { // While the node in path still has a parent that is not the start
            path.add(0, parent); // Add the parent to the head, since we are working backwards
            parent = parentMap.get(parent); // Set new parent using the parentMap
        }

        return path;
    }
}