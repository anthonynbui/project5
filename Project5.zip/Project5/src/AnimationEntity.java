import processing.core.PImage;

import java.util.List;

public abstract class AnimationEntity extends ActionEntity {

    private int animationPeriod;

    public AnimationEntity(String id, Point position,
                        List<PImage> images, int actionPeriod, int animationPeriod) {
        super(id, position, images, actionPeriod);
        this.animationPeriod = animationPeriod;
    }

    public int getAnimationPeriod() {
        return this.animationPeriod;
    }

    public void nextImage() {
        this.imageIndex = (this.imageIndex + 1) % this.images.size();
    }

    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        scheduler.unscheduleAllEvents(this);
        world.removeEntity(this);
    }

    public abstract void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore);

    public Animation createAnimationAction(Entity entity, int repeatCount) {
        return new Animation(entity, null, null, repeatCount);
    }

}
