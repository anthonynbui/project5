import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import processing.core.PImage;

public class Tornado extends ActionEntity {

    public static final String FISH_ID_PREFIX = "fish -- ";
    public static final int FISH_CORRUPT_MIN = 20000;
    public static final int FISH_CORRUPT_MAX = 30000;
    public static final int FISH_REACH = 1;

    public Tornado(String id, Point position,
                  List<PImage> images, int actionPeriod) {
        super(id, position, images, actionPeriod);
    }

    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        Optional<Point> openPt = world.findOpenAround(this.position);

        if (openPt.isPresent()) {
            Shark shark = Shark.createShark("shark", openPt.get(), 500, 1,
                    imageStore.getImageList("shark"),0);
            world.addEntity(shark);
            shark.scheduleActions(scheduler, world, imageStore);
        }

        scheduler.scheduleEvent(this,
                createActivityAction(this, world, imageStore),
                this.getActionPeriod());
    }

    public void transformOctoToPiranha(WorldModel world, EventScheduler scheduler, ImageStore imageStore, Point pressed) {
        Optional<Entity> nearestOcto = world.findNearest(pressed, Octo_Not_Full.class);
        if (nearestOcto.isPresent()) {
            Octo transform = ((Octo)(nearestOcto.get()));
            transform.mutate(world, scheduler, imageStore, transform);
            transform.scheduleActions(scheduler,world,imageStore);
        }
    }

    public static Tornado createTornado(String id, Point position, int actionPeriod,
                                      List<PImage> images) {
        return new Tornado(id, position, images, actionPeriod);
    }

}
