import processing.core.PImage;

import java.util.List;

public abstract class Octo extends MoveableEntity {

    private int resourceLimit;
    private int resourceCount;

    public Octo(String id, Point position, List<PImage> images, int actionPeriod, int animationPeriod,
                int resourceLimit, int resourceCount) {
        super(id, position, images, actionPeriod, animationPeriod);
        this.resourceLimit = resourceLimit;
        this.resourceCount = resourceCount;
    }

    public int getResourceLimit() {
        return this.resourceLimit;
    }

    public int getResourceCount() {
        return this.resourceCount;
    }

    public void addResourceCount(int i) {
        this.resourceCount += i;
    }

    public boolean mutate(WorldModel world,
                          EventScheduler scheduler, ImageStore imageStore, Entity ent) {
        Piranha piranha = Piranha.createPiranha("piranha",this.position, this.getActionPeriod(), this.getAnimationPeriod()
                , imageStore.getImageList("piranha"));
        world.removeEntity(ent);
        scheduler.unscheduleAllEvents(ent);
        world.addEntity(piranha);
        piranha.scheduleActions(scheduler, world, imageStore);

        return true;
    }
//    @Override
//    public Point nextPosition(WorldModel world,
//                              Point destPos) {
//        int horiz = Integer.signum(destPos.x - this.position.x);
//        Point newPos = new Point(this.position.x + horiz,
//                this.position.y);
//
//        if (horiz == 0 || world.isOccupied(newPos)) {
//            int vert = Integer.signum(destPos.y - this.position.y);
//            newPos = new Point(this.position.x,
//                    this.position.y + vert);
//
//            if (vert == 0 || world.isOccupied(newPos)) {
//                newPos = this.position;
//            }
//        }
//
//        return newPos;
//    }
}
