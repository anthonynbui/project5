import processing.core.PImage;

import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.Predicate;

public abstract class MoveableEntity extends AnimationEntity {

//    private SingleStepPathingStrategy pathing = new SingleStepPathingStrategy();
      private AStarPathingStrategy pathing = new AStarPathingStrategy();

    public MoveableEntity(String id, Point position,
                          List<PImage> images, int actionPeriod, int animationPeriod) {
        super(id, position, images, actionPeriod, animationPeriod);
    }

    public Point nextPosition(WorldModel world,
                                       Point destPos) { // nextPosition for all moveable entities
        List<Point> nextPos;
        nextPos = pathing.computePath(getPosition(), destPos, canPassThrough(world), withinReach() , PathingStrategy.CARDINAL_NEIGHBORS);
        // nextPos is path for this entity to take
        if (nextPos.size() == 0){ // if path is completed
            return getPosition();
        }
        return nextPos.get(0);
    }

    public Predicate<Point> canPassThrough(WorldModel world) {
        return point -> world.withinBounds(point) && !world.isOccupied(point);
    }

    public BiPredicate<Point, Point> withinReach(){
        return (p1, p2) -> p1.adjacent(p2);
    }

    public abstract boolean moveTo(WorldModel world,
                                   Entity target, EventScheduler scheduler);

    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this,
                createActivityAction(this, world, imageStore),
                this.getActionPeriod());
        scheduler.scheduleEvent(this,
                createAnimationAction(this, 0), this.getAnimationPeriod());
    }
}
